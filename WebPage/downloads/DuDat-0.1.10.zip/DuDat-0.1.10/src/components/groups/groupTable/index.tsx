import { GroupTable } from "./groupTable";

export default GroupTable;

import CenteredLayout from "./centeredLayout";
export default CenteredLayout;

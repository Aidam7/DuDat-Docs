import { CategoryTable } from "./categoryTable";
export default CategoryTable;

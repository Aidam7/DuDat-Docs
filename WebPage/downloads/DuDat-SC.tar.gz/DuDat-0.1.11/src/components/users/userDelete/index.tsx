import UserDelete from "./userDelete";
export default UserDelete;

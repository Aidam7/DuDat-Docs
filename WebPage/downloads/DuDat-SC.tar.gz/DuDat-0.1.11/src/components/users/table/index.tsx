import { UserTable } from "./table";
export default UserTable;

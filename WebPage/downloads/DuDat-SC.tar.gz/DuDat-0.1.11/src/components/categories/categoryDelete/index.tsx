import CategoryDelete from "./categoryDelete";
export default CategoryDelete;

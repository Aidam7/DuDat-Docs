import CategoryChipDisplay from "./categoryChipDisplay";
export default CategoryChipDisplay;

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "startedStreak" TIMESTAMP(3);

-- CreateIndex
CREATE INDEX "Task_title_idx" ON "Task"("title");

-- CreateIndex
CREATE INDEX "Task_confirmedAsFinished_idx" ON "Task"("confirmedAsFinished");

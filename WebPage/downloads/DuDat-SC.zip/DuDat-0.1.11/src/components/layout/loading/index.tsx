import Loading from "./loading";
export default Loading;

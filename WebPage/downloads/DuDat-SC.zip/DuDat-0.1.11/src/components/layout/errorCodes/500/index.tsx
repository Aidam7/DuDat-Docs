import Code500 from "./500";
export default Code500;

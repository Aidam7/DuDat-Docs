-- AlterTable
ALTER TABLE "Task" ADD COLUMN     "confirmedAsFinished" BOOLEAN NOT NULL DEFAULT false;

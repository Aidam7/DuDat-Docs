-- AlterTable
ALTER TABLE "Group" ADD COLUMN     "description" TEXT;

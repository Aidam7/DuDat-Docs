-- CreateIndex
CREATE INDEX "Category_groupId_idx" ON "Category"("groupId");

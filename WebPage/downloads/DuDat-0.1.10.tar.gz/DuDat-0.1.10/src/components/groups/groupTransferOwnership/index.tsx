import GroupTransferOwnership from "./groupTransferOwnership";
export default GroupTransferOwnership;

import Code404 from "./404";
export default Code404;

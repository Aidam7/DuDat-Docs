import React from "react";
import Code500 from "~/components/layout/errorCodes/500";

const ServerErrorPage = () => {
  return <Code500 />;
};

export default ServerErrorPage;
